# 1.a
CPU: 4
CPU CORES: 2

# 1.b
cpu MHz		: 600.000
cpu MHz		: 599.999
cpu MHz		: 599.998
cpu MHz		: 600.001

# 1.c
MemTotal:        8057132 kB

# 1.d
MemFree:         1603560 kB
MemAvailable:    4049788 kB
Diff:            2446228 kB

# 1.e
Total number of user-level is 270.
