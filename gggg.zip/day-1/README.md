<p align="center">
  <strong>CS341</strong>
</p>

### How to use

```markdown
1. Download file you need form this repo.
2. Change permission of file `sudo chmod +x command.sh`
3. Run script file `./command.sh`
```
